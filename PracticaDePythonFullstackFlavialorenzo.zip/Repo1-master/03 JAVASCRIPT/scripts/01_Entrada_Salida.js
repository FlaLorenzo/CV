

//Salida por ventana emergente
alert("Esto es una ventana emergente.");

//Entrada de datos
var edad = prompt("Introduzca edad: ");

// Salida de datos leyendo desde una variable
alert("La edad introducida es: " + edad);

// Salida de datos por consola
console.log("Ha terminado el programa");

// Salida de datos al BODY de mi página
document.write("<h1>Esto es un H1 puesto desde javascript</h1>");
























