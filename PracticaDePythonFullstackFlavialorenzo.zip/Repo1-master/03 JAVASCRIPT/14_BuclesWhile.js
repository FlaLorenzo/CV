
//Bucle While
let contador = 0;
let ciclos = Number(prompt("Introduce número de ejecuciones"));

while(contador < ciclos){
    console.log("Contador vale ahora " + contador);
    contador++;
}




