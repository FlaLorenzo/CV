//Recorrer Arrays con un For

var nombres = ["Angel", "Sara", "Manolo", "Ana"];

for ( i = 0; i < nombres.length; i++) {
  document.write("<li>" + nombres[i] + "</li>");
}


//Recorre un array numérico
 var numbers = [3,54,67,100];

 for(i=0; i<numbers.length; i++){
    document.write(numbers[i]*10 + "<br>");
 }

