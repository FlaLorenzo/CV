//Recorrer Arrays con un For...In

var nombres = [
  "Angel",
  "Sara",
  "Manolo",
  "Ana"
];


for (let i in nombres) {
  document.write("<li>" + nombres[i] + "</li>");
}

