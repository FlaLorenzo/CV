
from Cuadrado import Cuadrado

cuadrado1 = Cuadrado(5, 'rojo')
print(f'Cálculo área cuadrado: {cuadrado1.calcular_area()}')
print(f'Color de la figura geométrica: {cuadrado1.color}')
