//IF anidado

let socio = true;
let moroso = true;

if(socio == true){
    if(moroso == true){
        alert("Es socio pero debe cuotas");
    }else{
        alert("Es socio al corriente de pago. Entrada permitida.");
    }
}else{
    alert("No se permite el acceso a NO socios");
}


