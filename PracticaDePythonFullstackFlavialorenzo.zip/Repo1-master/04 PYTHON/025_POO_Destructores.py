from Persona2 import Persona

print('Creación objetos'.center(30, '-'))
persona1 = Persona('Karla', 'Gomez', 30)
persona1.mostrar_detalle()

print('Eliminación objetos'.center(30, '-'))
del persona1
