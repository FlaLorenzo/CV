
# Los comentarios son anotaciones que pondremos en nuestro código que el programa no va a tener en cuenta.
# Existen dos tipos de comentarios:

# Esto es un comentario de una línea

"""Esto es un comentario
que me va a ocupar
varias líneas"""
