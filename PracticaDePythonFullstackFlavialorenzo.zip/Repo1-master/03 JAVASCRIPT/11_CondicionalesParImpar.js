let number = Number(prompt("Introduce un número."));

if(number % 2 == 0){
console.log("El número es par");
}
else{
    console.log("El número es impar");
}

