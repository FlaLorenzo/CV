//BUCLES

for (i = 0; i < 10; i++) {
  document.write("En esta vuelta de bucle I vale " + i);
  document.write("<br>");
}

document.write("Ejecución terminada.");


