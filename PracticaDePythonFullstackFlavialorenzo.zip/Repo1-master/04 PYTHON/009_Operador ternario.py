

#	Operador ternario

num = 12

var = "par" if (num % 2 == 0) else "impar"

print(var)

#	Sería como escribir

num = 12

if num % 2 == 0:
    print="Par"
else: print="Impar"


