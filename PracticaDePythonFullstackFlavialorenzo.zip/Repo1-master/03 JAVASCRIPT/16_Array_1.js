//Arrays

//Declaración de un array
var miArray;

//Inicialización de un Array
miArray = ["Angel", 635, true, "negro"];

//Declaración e Inicialización de un Array

var miArray2 = ["Angel", 635, true, "negro"];

//Imprimir el contenido de un array
console.log(miArray2[0]);

//Longitud de un array
console.log(miArray2.length);

//Los Strings son considerados como arrays de caracteres.
var miString = "Esto es una frase";
console.log(miString.length);

//Añadir elementos a un array en una determinada posición
miArray2[5] = "hombre";

//Añadir elementos de forma dinámica
miArray2[4] = prompt("Introduce el elemento en la posición 4:");
console.log(miArray2);

//Ultimo elemento de un array. Igual que en los Strings.
console.log(miArray[miArray.length - 1]);














